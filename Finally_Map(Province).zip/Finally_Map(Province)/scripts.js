const LAT_LNG = {
    "Phnom Penh": { "lat": 11.55, "lng": 104.9167 },
    "Banteay Meanchey": { "lat": 13.75321302, "lng": 102.9894965 },
    "Battambang": { "lat": 13.09931318, "lng": 103.201446 },
    "Kampong Cham": { "lat": 11.99255608, "lng": 105.4644398 },
    "Kampong Chhnang": { "lat": 12.26301485, "lng": 104.6758092 },
    "Kampong Speu": { "lat": 11.46461577, "lng": 104.5069304 },
    "Kampong Thom": { "lat": 12.71054553, "lng": 104.8726302 },
    "Kampot": { "lat": 10.59546349, "lng": 104.1635839 },
    "Kandal": { "lat": 11.45924382, "lng": 104.9447355 },
    "Koh Kong": { "lat": 11.61646283, "lng": 102.9806657 },
    "Kratie": { "lat": 12.49171489, "lng": 106.0281838 },
    "Mondulkiri": { "lat": 12.46140952, "lng": 107.1867941 },
    "Preah Vihear": { "lat": 13.79182713, "lng": 104.9811973 },
    "Prey Veng": { "lat": 11.48519196, "lng": 105.3280685 },
    "Pursat": { "lat": 12.46332833, "lng": 103.8946358 },
    "Ratanakiri": { "lat": 13.7404469, "lng": 106.9849218 },
    "Siem Reap": { "lat": 13.36624373, "lng": 103.8551901 },
    "Preah Sihanouk": { "lat": 10.63246112, "lng": 103.5115242 },
    "Stung Treng": { "lat": 13.50808806, "lng": 105.9675997 },
    "Svay Rieng": { "lat": 11.08794891, "lng": 105.8010019 },
    "Takeo": { "lat": 10.9897821, "lng": 104.7872742 },
    "Oddar Meanchey": { "lat": 14.16094341, "lng": 103.820847 },
    "Kep": { "lat": 10.54298299, "lng": 104.3189874 },
    "Pailin": { "lat": 12.91106163, "lng": 102.6675069 },
    "Tbong Khmum": { "lat": 11.88910999, "lng": 105.8759834 }
};


const GRAPH = {
    // Your GRAPH data 
    'Phnom Penh': {'Kandal': 14 },
    'Kandal': {'Phnom Penh': 14,'Takeo': 65, 'Kampong Speu': 66.3, 'Kampong Chhnang':106, 'Kampong Cham': 119,'Prey Veng': 90.5},
    'Takeo': {'Kandal': 65, 'Kampong Speu': 81.8,'Kampot': 89.6},
    'Kampong Speu': {'Takeo': 81.8, 'Kandal': 66.3, 'Kampong Chhnang':111, 'Pursat': 211, 'Koh Kong': 248, 'Kampot': 125, 'Preah Sihanouk': 166},
    'Kampong Chhnang': {'Kandal': 106, 'Kampong Speu': 111, 'Pursat': 106, 'Kampong Cham': 153,'Kampong Thom': 63.9},
    'Kampong Cham': {'Kampong Chhnang': 153, 'Kandal': 119, 'Prey Veng': 76, 'Tbong Khmum': 59.8, 'Kampong Thom': 110, 'Kratie': 113},
    'Kampong Thom': {'Kampong Chhnang': 63.9, 'Kampong Cham': 110, 'Preah Vihear': 144, 'Siem Reap': 159, 'Kratie': 174, 'Stung Treng': 238},
    'Kampot': {'Takeo': 89.6, 'Preah Sihanouk': 98.6, 'Kep': 22.9, 'Koh Kong': 239, 'Kampong Spue': 125},
    'Kep': {'Kampot': 22.9},
    'Preah Sihanouk': {'Kampot': 98.6, 'Kampong Spue': 166, 'Koh Kong': 223},
    'Koh Kong': {'Preah Sihanouk': 223, 'Kampot': 239, 'Kampong Spue': 248, 'Pursat': 238},
    'Pursat': {'Koh Kong': 238, 'Kampong Spue': 211, 'Kampong Chhnang': 106, 'Battambang': 117},
    'Prey Veng': {'Kandal': 90.5, 'Kampong Cham': 76, 'Tbong Khmum': 97.1, 'Svay Rieng': 92.6},
    'Tbong Khmum': {'Kampong Cham': 59.8, 'Prey Veng': 97.1, 'Kratie': 114},
    'Siem Reap': {'Kampong Thom': 159, 'Preah Vihear': 159, 'Battambang': 163, 'Banteay Meanchey': 104},
    'Preah Vihear': {'Kampong Thom': 144, 'Siem Reap': 159,'Stung Treng': 132, 'Oddar Meanchey': 132,},
    'Battambang': {'Pursat': 117, 'Banteay Meanchey': 68.1, 'Pailin': 78, 'Siem Reap': 163},
    'Banteay Meanchey': {'Battambang': 68.1, 'Siem Reap': 104, 'Oddar Meanchey': 101},
    'Pailin': {'Battambang': 78},
    'Svay Rieng': {'Prey Veng': 92.6},
    'Kratie': {'Kampong Cham': 113, 'Tbong Khmum': 114, 'Kampong Thom': 174, 'Stung Treng': 135,'Mondulkiri': 194},
    'Stung Treng': {'Kampong Thom': 238, 'Preah Vihear': 140, 'Kratie': 135, 'Ratanakiri': 138, 'Mondulkiri': 314},
    'Oddar Meanchey': {'Preah Vihear': 132, 'Banteay Meanchey': 101},
    'Mondulkiri': {'Stueng Treng': 314, 'Ratanakiri': 104, 'Kratie': 194},
    'Ratanakiri': {'Stung Treng': 138,'Mondulkiri': 104},
};

// Populate the select options
function populateSelectOptions() {
    const startSelect = document.getElementById("startProvince");
    const goalSelect = document.getElementById("goalProvince");

    for (let province in LAT_LNG) {
        const option = document.createElement("option");
        option.value = province;
        option.textContent = province;

        startSelect.appendChild(option.cloneNode(true));
        goalSelect.appendChild(option);
    }
}

populateSelectOptions();


const map = L.map('map').setView([12.5655, 104.9910], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

Object.keys(LAT_LNG).forEach(province => {
    const { lat, lng } = LAT_LNG[province];
    L.marker([lat, lng]).addTo(map).bindPopup(province);
});

document.getElementById("searchButton").addEventListener("click", function() {
    const startProvince = document.getElementById("startProvince").value;
    const goalProvince = document.getElementById("goalProvince").value;
    const selectedModel = document.getElementById("model").value;
    const path = searchPath(GRAPH, startProvince, goalProvince, selectedModel);
    drawPath(path);
});


function drawPath(path) {
    // The drawPath function as defined before...
    map.eachLayer(layer => {
        if (layer instanceof L.Polyline) {
            map.removeLayer(layer);
        }
    });

    if (path.length < 2) {
        document.getElementById("totalDistance").textContent = "No valid path found.";
        document.getElementById("pathDetails").innerHTML = ""; // Clear previous details
        return;
    }

    const latLngs = [];
    let totalDistance = 0;
    let totalStraightLineDistance = 0;
    let pathDetails = "";

    for (let i = 0; i < path.length - 1; i++) {
        const startNode = path[i];
        const endNode = path[i + 1];
        const distance = GRAPH[startNode][endNode] || 0;
        const straightLineDistance = calculateStraightLineDistance(startNode, endNode);

        latLngs.push([LAT_LNG[startNode].lat, LAT_LNG[startNode].lng]);
        latLngs.push([LAT_LNG[endNode].lat, LAT_LNG[endNode].lng]);
        totalDistance += distance;
        totalStraightLineDistance += straightLineDistance;

        pathDetails += `${startNode} to ${endNode}: ${distance} km (Straight: ${straightLineDistance.toFixed(2)} km)<br>`;
    }

    document.getElementById("totalDistance").innerHTML = `
        Total Distance from Start to Goal: ${totalDistance} km<br>
        Total Straight Line Distance: ${totalStraightLineDistance.toFixed(2)} km
    `;
    document.getElementById("pathDetails").innerHTML = `
        <div class="text-2xl font-bold ps-4 pt-4">Result : </div>
        <div class="ps-4">
            <div class="font-bold">Path Details:</div>
            ${pathDetails}
        </div>
        <br>
        <hr>
    `;

    if (latLngs.length > 0) {
        L.polyline(latLngs, { color: 'red' }).addTo(map);
    }
}
function searchPath(graph, start, goal, algorithm) {
    // The searchPath function as defined before...
    if (!graph[start]) {
        alert("Start province not found in the graph.");
        return [];
    }
    if (!graph[goal]) {
        alert("Goal province not found in the graph.");
        return [];
    }
    if (algorithm === "bfs") return bfs(graph, start, goal);
    if (algorithm === "dfs") return dfs(graph, start, goal);
    if (algorithm === "gbfs") return gbfs(graph, start, goal);
    if (algorithm === "astar") return astar(graph, start, goal);
    return [];
}

function calculateStraightLineDistance(start, end) {
    // The calculateStraightLineDistance function as defined before...
    const R = 6371; // Radius of the Earth in km
    const lat1 = LAT_LNG[start].lat * (Math.PI / 180);
    const lon1 = LAT_LNG[start].lng * (Math.PI / 180);
    const lat2 = LAT_LNG[end].lat * (Math.PI / 180);
    const lon2 = LAT_LNG[end].lng * (Math.PI / 180);

    const dLat = lat2 - lat1;
    const dLon = lon2 - lon1;

    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1) * Math.cos(lat2) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in km
}

function bfs(graph, start, goal) {
    const queue = [[start]];
    const explored = new Set();

    while (queue.length > 0) {
        const path = queue.shift();
        const node = path[path.length - 1];

        if (node === goal) {
            return path;
        }


        if (!explored.has(node)) {
            explored.add(node);
            for (let neighbor in graph[node]) {
                const newPath = [...path, neighbor];
                queue.push(newPath);
            }
        }
    }
    return [];
}

function dfs(graph, start, goal) {
    const stack = [[start]];
    const explored = new Set();

    while (stack.length > 0) {
        const path = stack.pop();
        const node = path[path.length - 1];

        if (node === goal) {
            return path;
        }

        if (!explored.has(node)) {
            explored.add(node);
            for (let neighbor in graph[node]) {
                const newPath = [...path, neighbor];
                stack.push(newPath);
            }
        }
    }
    return [];
}

function gbfs(graph, start, goal) {
    const frontier = [[start]];
    const explored = new Set();

    while (frontier.length > 0) {
        frontier.sort((a, b) => LAT_LNG[a[a.length - 1]].lat - LAT_LNG[b[b.length - 1]].lat);
        const path = frontier.shift();
        const node = path[path.length - 1];

        if (node === goal) {
            return path;
        }

        if (!explored.has(node)) {
            explored.add(node);
            for (let neighbor in graph[node]) {
                const newPath = [...path, neighbor];
                frontier.push(newPath);
            }
        }
    }
    return [];
}

function astar(graph, start, goal) {
    const frontier = [[start]];
    const costSoFar = new Map();
    costSoFar.set(start, 0);
    while (frontier.length > 0) {
        frontier.sort((a, b) => (costSoFar.get(a[a.length - 1]) || 0) - (costSoFar.get(b[b.length - 1]) || 0));
        const path = frontier.shift();
        const node = path[path.length - 1];

        if (node === goal) {
            return path;
        }

        for (let neighbor in graph[node]) {
            const newPath = [...path, neighbor];
            const newCost = costSoFar.get(node) + (graph[node][neighbor] || 0);
            if (!costSoFar.has(neighbor) || newCost < costSoFar.get(neighbor)) {
                costSoFar.set(neighbor, newCost);
                frontier.push(newPath);
            }
        }
    }
    return [];
}